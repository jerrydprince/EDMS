<template>
    <main class="flex border h-[91vh] overflow-hidden">
        <!-- Left Sidebar - Branch Groups/Direct Messages -->
        <section
            class="w-full lg:w-[25%] border-r border-solid border-gray-200 top-0 h-[100%] py-3 transition-all duration-300"
            :class="{ 'hidden lg:block': open }"
            v-if="activeButton === 0"
        >
            <div class="px-3">
                <div
                    class="flex items-center justify-between text-[#1D2939] text-2xl lg:text-3xl font-semibold"
                >
                    <h1 class="">Chats</h1>
                </div>

                <div
                    class="flex items-center justify-between mt-5 w-full gap-2"
                >
                    <div
                        class="flex items-center border flex-1 lg:w-[85%] border-solid rounded-3xl px-3 bg-gray-100"
                    >
                        <Icon
                            icon="lucide:search"
                            class="text-lg text-gray-500"
                        />
                        <input
                            type="text"
                            v-model="filter_users"
                            @input="filterRecipients"
                            placeholder="Search Users"
                            class="outline-none h-full p-2 bg-gray-100 w-full"
                        />
                    </div>
                    <div class="mr-1 flex-none">
                        <Icon
                            icon="ion:filter-sharp"
                            width="30"
                            class="lg:w-[35px]"
                        />
                    </div>
                </div>
            </div>

            <div class="mt-5 px-3 lg:px-0">
                <TabMenu
                    v-model:activeIndex="active"
                    :model="items"
                    :pt="{
                        root: { class: 'text-primary' },
                        inkbar: { class: 'text-primary' },
                        action: ({ props, context, state }) => ({
                            class: `${
                                context.index === state.d_activeIndex
                                    ? 'text-primary border-b-2 border-solid border-primary'
                                    : ''
                            } p-1 pr-0 md:pr-1 md:p-3 pl-1 text-gray-500 -mb-[2px]`,
                        }),
                    }"
                >
                    <template #item="{ item, props }">
                        <p
                            v-bind="props.action"
                            class="flex align-items-center gap-1 md:gap-2 text-xs md:text-sm"
                        >
                            <span
                                class="font-semibold text-xs md:text-sm cursor-pointer"
                                >{{ item.label }}</span
                            >
                        </p>
                    </template>
                </TabMenu>
            </div>
            <!-- ======================  Branch Group ============="" -->
            <div v-if="active === 0">
                <div
                    class="overflow-scroll h-[50vh] lg:h-[50vh] pb-20 hide_scroll px-3 pr-7 mt-5"
                >
                    <div
                        class="grid grid-cols-2 gap-3 lg:gap-5 justify-between"
                    >
                        <div
                            v-for="(item, index) in userGroups"
                            :key="index"
                            class=""
                            @click="handleGroups(item, index)"
                        >
                            <div
                                class="flex items-center justify-center flex-col p-2 lg:p-3 border border-solid cursor-pointer rounded-md border-gray-300"
                            >
                                <div
                                    class="text-primary border bg-white p-2 lg:p-3 w-fit rounded-full"
                                >
                                    <img
                                        :src="getImageForGroup(index)"
                                        alt=""
                                        class="w-6 h-6 lg:w-auto lg:h-auto"
                                    />
                                </div>
                                <p
                                    class="mt-2 font-semibold text-xs lg:text-base"
                                >
                                    {{ index }}
                                </p>
                                <small class="capitalize text-xs"
                                    >({{
                                        item && item.length > 0
                                            ? item.length
                                            : 0
                                    }}
                                    <span class="capitalize">{{ index }}</span
                                    >)</small
                                >
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- =============    Direct Messages    =========== -->
            <div class="" v-else>
                <div
                    v-if="filter_users && Suggestions.length > 0"
                    class="overflow-scroll h-[60vh] lg:h-[65vh] pb-10 hide_scroll"
                >
                    <div
                        v-for="(suggestion, index) in Suggestions"
                        :key="index"
                        class="cursor-pointer"
                        @click="toggleBackgroundUser(suggestion)"
                    >
                        <div
                            class="flex items-center py-3 px-3 justify-between w-full"
                            :class="{
                                ' bg-[#F5F9FF]': clickedIndex === suggestion.id,
                            }"
                        >
                            <div class="flex items-center gap-3 w-full">
                                <img
                                    :src="'/assets/images/display_picture.svg'"
                                    alt=""
                                    class="flex-none w-8 h-8 lg:w-auto lg:h-auto"
                                />
                                <div
                                    class="flex items-center justify-between w-full"
                                >
                                    <div>
                                        <h1
                                            class="font-semibold text-sm lg:text-base"
                                        >
                                            {{ suggestion.name }}
                                        </h1>
                                    </div>
                                    <div class="p-1 border rounded-full">
                                        <Icon
                                            icon="uil:angle-right-b"
                                            width="20"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    v-else
                    class="overflow-scroll h-[60vh] lg:h-[65vh] pb-10 hide_scroll"
                >
                    <div
                        v-for="(item, index) in users"
                        :key="index"
                        class="cursor-pointer"
                        @click="toggleBackgroundUser(item)"
                    >
                        <div
                            class="flex items-center py-3 px-3 justify-between w-full"
                            :class="{
                                ' bg-[#F5F9FF]': clickedIndex === item.id,
                            }"
                        >
                            <div class="flex items-center gap-3 w-full">
                                <img
                                    v-if="message.profile_image"
                                    :src="
                                        page.props.base +
                                        message.sender +
                                        '/' +
                                        message.profile_image
                                    "
                                    alt=""
                                    class="w-8 h-8 lg:w-auto lg:h-auto"
                                />
                                <img
                                    v-else
                                    :src="'/assets/images/display_picture.svg'"
                                    alt=""
                                    class="flex-none w-8 h-8 lg:w-auto lg:h-auto"
                                />
                                <div
                                    class="flex items-center justify-between w-full"
                                >
                                    <div>
                                        <h1
                                            class="font-semibold text-sm lg:text-base"
                                        >
                                            {{ item.first_name }}
                                        </h1>
                                        <p class="text-xs lg:text-sm">
                                            no message yet
                                        </p>
                                    </div>
                                    <div class="p-1 border rounded-full">
                                        <Icon
                                            icon="uil:angle-right-b"
                                            width="20"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Middle Sidebar - Group List -->
        <section
            class="w-full lg:w-[25%] border-r border-solid border-gray-200 top-0 h-[100%] py-3 transition-all duration-300"
            :class="{ 'hidden lg:block': open }"
            v-if="activeButton === 1"
        >
            <div class="flex items-center gap-3 px-3">
                <div
                    class="p-2 border rounded-md cursor-pointer"
                    @click="activeButton = 0"
                >
                    <Icon
                        icon="material-symbols:arrow-back"
                        width="25"
                        class="lg:w-[30px]"
                    />
                </div>
                <div class="flex">
                    <h1 class="font-semibold text-xl lg:text-2xl pr-3">
                        {{ groupType }}
                    </h1>
                    <p
                        class="opacity-70 mt-1 text-sm lg:text-base"
                        v-if="selectedBranchGroup"
                    >
                        ({{ selectedBranchGroup?.length }})
                    </p>
                </div>
            </div>

            <div
                class="flex items-center border mx-3 my-5 border-solid rounded-3xl px-3 bg-gray-100"
            >
                <Icon icon="lucide:search" class="text-lg text-gray-500" />
                <input
                    type="text"
                    v-model="filter_groups"
                    :placeholder="'search ' + groupType"
                    class="outline-none h-full p-2 bg-gray-100 w-full"
                />
            </div>

            <div
                v-if="groups && groups.length > 0"
                class="overflow-scroll h-[70vh] pb-10 hide_scroll"
            >
                <div
                    v-for="(item, index) in filterGroups"
                    :key="index"
                    class="cursor-pointer"
                >
                    <div
                        class="flex items-center py-3 px-3 justify-between w-full"
                        :class="{
                            ' bg-[#F5F9FF]': open && item.id == groupIndex,
                        }"
                    >
                        <div
                            class="flex items-center gap-3 w-full"
                            @click="toggleGroup(item)"
                        >
                            <div
                                class="text-primary border border-gray-300 bg-white p-2 rounded-full overflow-hidden flex-none"
                            >
                                <img
                                    :src="current_img"
                                    alt=""
                                    class="w-6 h-6 lg:w-auto lg:h-auto"
                                />
                            </div>
                            <div
                                class="flex items-center justify-between w-full"
                            >
                                <div>
                                    <h1
                                        class="font-semibold text-sm lg:text-base flex"
                                    >
                                        {{ item.title }}
                                    </h1>

                                    <p
                                        class="text-[#98A2B3] text-xs lg:text-sm"
                                    >
                                        {{
                                            item.users ? item.users.length : ""
                                        }}
                                        Members
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div
                            class="p-1 border rounded-full"
                            @click="toggleGroupUsers(item)"
                        >
                            <Icon icon="uil:angle-right-b" width="20" />
                        </div>
                        <div></div>
                    </div>

                    <div v-if="toggleUsers && groupIndex == item.id">
                        <div
                            v-for="(user, index) in item.users"
                            :key="index"
                            class="cursor-pointer px-6 lg:px-10"
                            @click="toggleBackgroundUser(user)"
                        >
                            <div
                                class="flex items-center py-3 px-3 justify-between w-full"
                                :class="{
                                    ' bg-[#F5F9FF]':
                                        open && clickedIndex === user.id,
                                }"
                            >
                                <div class="flex items-center gap-3 w-full">
                                    <img
                                        v-if="user.profile_image"
                                        :src="
                                            page.props.base +
                                            '/' +
                                            user.profile_image
                                        "
                                        width="30"
                                        alt=""
                                        class="w-8 h-8 lg:w-auto lg:h-auto"
                                    />
                                    <img
                                        v-else
                                        :src="'/assets/images/display_picture.svg'"
                                        alt=""
                                        class="flex-none w-8 h-8 lg:w-auto lg:h-auto"
                                    />
                                    <div
                                        class="flex items-center justify-between w-full"
                                    >
                                        <div>
                                            <h1
                                                class="font-semibold text-sm lg:text-base"
                                            >
                                                {{
                                                    user.first_name +
                                                    " " +
                                                    user.last_name
                                                }}
                                            </h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Messages Section -->
        <section
            class="w-full lg:w-[75%] transition-all duration-300"
            :class="{ 'hidden lg:block': !open }"
        >
            <div v-if="open">
                <div v-if="active === 0 || active === 1">
                    <Messages
                        :selectedUser="selectedUser"
                        :selectedMessage="selectedMessage"
                        :clickedIndexGroup="clickedIndexGroup"
                        :clickedIndex="clickedIndex"
                        :selectedMessageGroup="selectedMessageGroup"
                        :allMessagess="allMessagess"
                        :groupType="groupType"
                        :clickedIndexGroupName="clickedIndexGroupName"
                        :is_single="is_single"
                        :is_group="is_group"
                        :selectedGroup="selectedGroup"
                        @back="handleBackToList"
                    />
                </div>
            </div>
            <div v-else>
                <EmptyChatRoom />
            </div>
        </section>
    </main>

    <AddLink v-model="addLinkModal" />
    <ReportDialog v-model="reportModal" />
</template>

<script setup>
import { ref, onMounted, watch, computed } from "vue";
import { usePage } from "@inertiajs/vue3";
import EmptyChatRoom from "../../components/EmptyChatRoom.vue";
import ReportDialog from "../../components/Modals/chat/ReportDialog.vue";
import AddLink from "../../components/Modals/chat/AddLink.vue";
import Messages from "../../components/Messages.vue";
import { useStore } from "vuex";

const clickedIndex = ref(null);
const clickedIndexGroup = ref(null);
const groups = ref([]);
const activeButton = ref(0);
const active = ref(0);
const addLinkModal = ref(false);
const reportModal = ref(false);
const open = ref(false);
const selectedMessage = ref();
const selectedMessageGroup = ref();
const allMessagess = ref([]);
const newbox = ref([]);
const Branch_group = ref([]);
const userGroups = ref([]);
const inbox = ref([]);
const Suggestions = ref([]);
const filter_users = ref("");
const page = usePage();
const current_img = ref(null);
const groupType = ref(null);
const groupIndex = ref(null);
const user = computed(() => page.props.user);
const users = ref([]);
const userBranch = computed(() => page.props.userBranch);
const store = useStore();
const global_chat = computed(() => store.getters.getNewChat);
const clickedIndexGroupName = ref("");
const selectedUser = ref();
const is_group = ref(false);
const is_single = ref(false);
const toggleUsers = ref(false);
const selectedGroup = ref([]);
const selectedBranchGroup = ref();
const filter_groups = ref("");
const filtered_groups = ref([]);

const notifications = computed(() => store.getters.getNotifications);

function toggleGroup(item) {
    groupIndex.value = item.id;
    filter_users.value = "";
    Suggestions.value = [];
    selectedMessage.value = item;
    selectedMessageGroup.value = item;
    selectedMessage.value = [];
    // selectedMessage.value['user'] = item
    open.value = true;
    clickedIndex.value = item?.user?.id;
    clickedIndexGroup.value = item?.id;
    clickedIndexGroupName.value = item?.title;
    //selectedUser.value['type'] = 'group'
    is_group.value = true;
    is_single.value = false;
    selectedGroup.value = item;
}

const filterGroups = computed(() => {
    if (filter_groups.value == "") {
        return groups.value;
    } else {
        return groups.value.filter((item) => {
            return item.title
                .toLowerCase()
                .includes(filter_groups.value.toLowerCase());
        });
    }
});

function toggleBackgroundUser(item) {
    // groupIndex.value = item.id
    filter_users.value = "";
    Suggestions.value = [];
    selectedUser.value = item;
    selectedUser.value["type"] = "single";
    open.value = true;
    is_group.value = false;
    is_single.value = true;
    clickedIndex.value = item.id;
}

function handleKeyDown(event) {
    if (event.key === "Escape") {
        open.value = false;
    }
}

const getUserBranch = () => {
    if (userBranch.value.unit) {
        return "unit";
    } else if (userBranch.value.division) {
        return "division";
    } else if (userBranch.value.department) {
        return "department";
    } else {
        return "others";
    }
};

const handleBackToList = () => {
    open.value = false;
    clickedIndex.value = null;
    clickedIndexGroup.value = null;
};

const getItemCount = (itm) => {
    let filtered = global_chat.value.filter((item) => {
        return item.group_id == itm.id && item.group_type == groupType.value;
    });

    console.log("this is the filtered list ", filtered);
    return filtered ? filtered.length : 0;
};

const getUserBranchId = () => {
    if (userBranch.value.unit) {
        return userBranch.value.unit.id;
    } else if (userBranch.value.division) {
        return userBranch.value.division.id;
    } else if (userBranch.value.department) {
        return userBranch.value.department.id;
    }
};

const toggleGroupUsers = (item) => {
    groupIndex.value = item.id;

    toggleUsers.value = !toggleUsers.value;
};

function getImageForGroup(item) {
    switch (item) {
        case "department":
            return page.props.base + "/images/department_active.svg";
        case "division":
            return page.props.base + "/images/division_active.svg";
        case "unit":
            return page.props.base + "/images/unit_active.svg";
        default:
            return ""; // Fallback or default image
    }
}

document.addEventListener("keydown", handleKeyDown);
const message = ref("");

const items = ref([{ label: "Branch Groups" }, { label: "Direct Messages" }]);
const handleGroups = (item, index) => {
    activeButton.value = 1;
    groups.value = item;
    current_img.value = getImageForGroup(index);
    is_group.value = true;
    is_single.value = false;
    selectedBranchGroup.value = item;

    if (index == "department") {
        groupType.value = "department";
    } else if (index == "division") {
        groupType.value = "division";
    } else {
        groupType.value = "unit";
    }

    // const newValues = ["gg:organisation", "icon-park-outline:fork", "tabler:box"]
    // groups.value.forEach((obj, index) => {
    //     obj.icon = newValues[0]
    // })
};
const getAllCategories = async () => {
    const token = localStorage.getItem("token");
    try {
        const response = await axios.get("/dashboard/chat/categories", {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        Branch_group.value = response.data;
        const newValues = [
            "gg:organisation",
            "icon-park-outline:fork",
            "tabler:box",
        ];
        Branch_group.value.forEach((obj, index) => {
            obj.icon = newValues[index];
        });
        Branch_group.value.forEach((obj, index) => {
            obj.icon = newValues[index];
        });
        Branch_group.value.forEach((obj, index) => {
            obj.icon = newValues[index];
        });
    } catch (error) {}
};
const getAllUserAndMessage = async () => {
    const token = localStorage.getItem("token");
    try {
        const response = await axios.get("/dashboard/chat/users", {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        //inbox.value = response.data;
        users.value = response.data;
    } catch (error) {}
};
watch(
    () => inbox.value,
    (checkbox) => {
        newbox.value = checkbox;
    }
);

const filterRecipients = () => {
    const searchTerm = filter_users.value.toLowerCase();

    const combinedArray = inbox.value.concat(Branch_group.value);
    Suggestions.value = combinedArray.filter((item) => {
        if (item?.name) {
            return item?.name.toLowerCase().includes(searchTerm);
        }
        if (Array.isArray(item.groups)) {
            return item.groups.some((subItem) =>
                subItem?.name?.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        return false;
    });
};

async function fetchUserGroups() {
    const token = localStorage.getItem("token");
    try {
        const response = await axios.get("/dashboard/chat/all-groups", {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        userGroups.value = response.data;
    } catch (error) {
        console.log(error);
    }
}

function listenToGroupMessages(groups) {
    //this line to be reviewed
    let total_length = Object.keys(groups).length;

    // if(groups && total_length > 0){
    //     groups.forEach(group => {
    //     let userId = window.authUserId;

    //     // window.Echo.private(`group.${group.id}`)
    //     //     .listen('GroupMessageSent', (event) => {
    //     //         console.log('from group:', group.id, event);
    //     //         allMessagess.value = event.message;
    //     //         console.log("listened", allMessagess.value.sender_id)
    //     //         allMessagess.value.is_sent_by_logged_in_user = allMessagess.value.sender_id === userId;
    //     //     });
    //     let groupType = getUserBranch()

    // });

    // }
    let grouptype = getUserBranch();
    for (let grp in groups) {
        if (groups.hasOwnProperty(grp)) {
            let branch = null;
            if (grouptype == "unit") {
                branch = userBranch.value["unit"];
            }
            if (grouptype == "division") {
                branch = userBranch.value["division"];
            }
            if (grouptype == "department") {
                branch = userBranch.value["department"];
            }
        }
    }

    let branch_id = getUserBranchId();
    window.Echo.private(`group.${branch_id}.${grouptype}`).listen(
        "GroupMessageSent",
        (event) => {
            allMessagess.value = event.message;

            allMessagess.value.is_sent_by_logged_in_user =
                allMessagess.value.sender_id === user.value.id;
            //if(event.message.group_id == clickedIndexGroup.value && event.message.group_type === grouptype){
            let data = {
                group_type: grouptype,
                group_id: event.message.group_id,
                type: "chat",
                chat: event.message,
                date: new Date(),
            };
            store.commit("setNewChat", data);
            // store.commit('setNotifications', values)
            // }
        }
    );
}
onMounted(async () => {
    try {
        await fetchUserGroups();
        listenToGroupMessages(userGroups.value);

        getAllUserAndMessage();
        getAllCategories();
        let userId = user.value.id;

        window.Echo.private(`chat.${userId}`).listen("MessageSent", (event) => {
            allMessagess.value = event.message;
            allMessagess.value.is_sent_by_logged_in_user =
                allMessagess.value.sender_id === userId;
            //store.commit('setNewChat')
        });

        Window.Echo.join(`presence.${userId}`).here((users) => {
            console.log("user is online", users);
        });
    } catch (error) {}
});
</script>

<style scoped>
.p-inputtextarea {
    border: none;
    outline: none;
    box-shadow: none !important;
    resize: none;
    width: 100%;
}

.p-inputtextarea:focus {
    border-color: transparent;
    /* Hide border */
    outline: none;
    /* Remove outline */
}

.switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

.slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: 0.4s;
    transition: 0.4s;
}

input:checked + .slider {
    background-color: #2196f3;
}

input:focus + .slider {
    box-shadow: 0 0 1px #2196f3;
}

input:checked + .slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
    border-radius: 34px;
}

.slider.round:before {
    border-radius: 50%;
}
</style>
